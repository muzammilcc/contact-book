<?php 
$fname =  $lname = $email = $password = $state = $zip = '';
$alert = false;
$success = false;
if($_SERVER['REQUEST_METHOD']=="POST"){
    include "include/config.php";
    // Checking if all field are empty or not
    if(empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['state']) || empty($_POST['zip'])){
        $alert = 'Field Are Empty';
    }else{
        $fname = mysqli_real_escape_string($conn,$_POST['fname']);
        $lname = mysqli_real_escape_string($conn,$_POST['lname']);
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $password = mysqli_real_escape_string($conn,$_POST['password']);
        $state = mysqli_real_escape_string($conn,$_POST['state']);
        $zip = mysqli_real_escape_string($conn,$_POST['zip']);
        // checking user name is taken or not 
        $user_sql = "SELECT * FROM `details` where `email` = '$email'";
        $result_user = mysqli_query($conn, $user_sql);
        if(mysqli_num_rows($result_user)>0){
            $alert = 'E-mail Already Taken';
        }else{
            // Hashing Password for safety
            $hash_pass = password_hash($password,PASSWORD_DEFAULT);
            // if all field are filled save to database
            $insert_sql = "INSERT INTO `details` (`fname`,`lname`,`email`,`password`,`state`,`zip`) VALUES ('$fname','$lname','$email','$hash_pass','$state','$zip')";
            $result_insert = mysqli_query($conn,$insert_sql);
            if($result_insert){
                $success = 'Account Created Successfully &nbsp;<a href="login.php">Login Here</a>';
            }
        }
    }
           
        
           
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Register</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Create Account</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
                                    <?php 
                                        if($success){
                                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong>Success !</strong> '.$success.'
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>';
                                        }
                                        if($alert){
                                            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <strong>Error !</strong> '.$alert.'
                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>';
                                        }
                                    ?>
                                                            <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputFirstName" type="text"
                                                        placeholder="Enter your first name" name="fname" />
                                                    <label for="inputFirstName">First name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" id="inputLastName" type="text"
                                                        placeholder="Enter your last name" name="lname" />
                                                    <label for="inputLastName">Last name</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="email" type="text"
                                                        placeholder="Example@gmail.com" name="email" />
                                                    <label for="email">E-mail</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputPassword" type="password"
                                                        placeholder="Create a password" name="password" />
                                                    <label for="inputPassword">Password</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <select class="form-select" id="validationDefault04" name="state">
                                                        <option selected disabled value="">Choose...</option>
                                                        <option value="Gujarat"
                                                            <?php if($state == "Gujarat") echo 'selected'; ?>>Gujarat
                                                        </option>
                                                        <option value="Maharashtra"
                                                            <?php if($state == "Maharashtra") echo 'selected'; ?>>
                                                            Maharashtra
                                                        </option>
                                                        <option value="Delhi"
                                                            <?php if($state == "Delhi") echo 'selected'; ?>>
                                                            Delhi</option>
                                                        <option value="Rajasthan"
                                                            <?php if($state == "Rajasthan") echo 'selected'; ?>>
                                                            Rajasthan
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" id="inputLastName" type="text"
                                                        placeholder="Zip Code" name="zip" />
                                                    <label for="inputLastName">Zip</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid">
                                                <input type="submit" name="btn" class="btn btn-primary btn-block"
                                                    value="Create Account">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <div class="small"><a href="login.php">Have an account? Go to login</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-center small">
                        <div class="text-muted">Copyright &copy; iMac 2022</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="js/scripts.js"></script>
</body>

</html>