<?php 
session_start();
$password = $cpass = '';
$alert = '';
include 'include/config.php';    
if($_SERVER['REQUEST_METHOD']=="POST"){
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $cpass = mysqli_real_escape_string($conn,$_POST['cpass']);
    if($password == $cpass){
        $hash_pass = password_hash($password,PASSWORD_DEFAULT);
        $update_pass = "UPDATE `details` SET `password` = '$hash_pass' WHERE `id` = '{$_SESSION['id']}';";
        $result = $conn->query($update_pass);
        if($result){
            header("location: logout.php");
        }else{
            $alert = "<div class='alert alert-danger'>Something Went Wrong</div>";
        }
    }else{
        $alert = "<div class='alert alert-danger'>Password Do Not Match</div>";
    }
}   

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>New Password</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Password Recovery</h3></div>
                                    <div class="card-body">
                                        <div class="small mb-3 text-muted">Enter your email address and we will send you a link to reset your password.</div>
                                        <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">  
                                            <?php 
                                            if($alert){
                                                echo $alert;
                                            }
                                            ?>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" type="email" disabled placeholder="name@example.com" name="email" value="<?php echo $_SESSION['email']; ?>"/>
                                                <label for="inputEmail">Email address</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="pass" type="password"  placeholder="name@example.com" name="password" />
                                                <label for="pass">Password</label>
                                            </div><div class="form-floating mb-3">
                                                <input class="form-control" id="cpass" type="password"  placeholder="name@example.com" name="cpass" />
                                                <label for="cpass">Confirm Password</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="small" href="logout.php">Return to login</a>
                                                <input type="submit" name="btn" class="btn btn-primary">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-center small">
                            <div class="text-muted">Copyright &copy; iMac 2022</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
