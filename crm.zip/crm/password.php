<?php 
$email = '';
$alert = '';
include 'include/config.php';
if($_SERVER['REQUEST_METHOD']=="POST"){
   if(empty($_POST['email'])){
    $alert = "<div class='alert alert-danger'>E-mail Field Empty</div>";
   }else{
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $show_id_sql = "SELECT * from `details` where `email` = '{$email}'";
    $result_id = mysqli_query($conn,$show_id_sql);
    if(mysqli_num_rows($result_id)>0){
        while($row = mysqli_fetch_assoc($result_id)){
            session_start();
            $_SESSION['id'] = $row['id'];
            $_SESSION['email'] = $email;
            header("location: newpassword.php");
        }
       
    }else{
        $alert = "<div class='alert alert-danger'>Invalid E-mail Address</div>";
    }
   }
}

?>
<form>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Name</label>
                                            <input type="text" class="form-control">
                                            <div class="mb-3">
                                                <label class="form-label">Mobile.no</label>
                                                <input type="number" class="form-control">
                                            </div>

                                            <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Password Reset</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Password Recovery</h3></div>
                                    <div class="card-body">
                                        <div class="small mb-3 text-muted">Enter your email address and we will reset your password.</div>
                                        <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">  
                                            <?php 
                                            if($alert){
                                                echo $alert;
                                            }
                                            ?>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" type="email" placeholder="name@example.com" name="email"/>
                                                <label for="inputEmail">Email address</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="small" href="login.php">Return to login</a>
                                                <input type="submit" name="btn" class="btn btn-primary">
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <div class="small"><a href="index.php">Need an account? Sign up!</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-center small">
                            <div class="text-muted">Copyright &copy; iMac 2022</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
