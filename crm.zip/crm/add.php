<?php 
// for Contact Adding in database
function addContact(){
    $u_id = $_GET['id'];
    $cname = $cnum = '';
    if(isset($_POST['cbtn'])){
        include 'include/config.php';
        $cname = mysqli_real_escape_string($conn,$_POST['cname']);
        $cnum = mysqli_real_escape_string($conn,$_POST['cnum']);
        $contact_sql = "INSERT INTO `contact` (`cname`, `number`, `uid`, `datetime`) VALUES ('$cname', '$cnum', '$u_id', current_timestamp());";
        $contact_result = $conn->query($contact_sql);
        if($contact_result){
            header("location: dashboard.php?id=".$u_id);
        }else{
            header("location: dashboard.php?id=".$u_id);
        }
    }
}
if($_GET['id'] || isset($_POST['cbtn'])){
    addContact();
}
// Adding Notes
function addNotes(){
    $n_id = $_GET['id'];
    $note_title = $note_desc =  '';
    if(isset($_POST['nbtn'])){
        include 'include/config.php';
        $note_title = mysqli_real_escape_string($conn,$_POST['notetitle']);
        $note_desc = mysqli_real_escape_string($conn,$_POST['notedesc']);
        $contact_sql = "INSERT INTO `notes` (`ntitle`, `ndesc`, `uid`, `datetime`) VALUES ('$note_title', '$note_desc', '$n_id', current_timestamp());";
        $contact_result = $conn->query($contact_sql);
        if($contact_result){
            header("location: dashboard.php?id=".$n_id);
        }else{
            header("location: dashboard.php?id=".$n_id);
        }
    }
}
if($_GET['id'] || isset($_POST['nbtn'])){
    addNotes();
}
?>