<?php 
session_start();
function DeleteContact(){
    include 'include/config.php';
    $c_id = $_GET['cid'];
    $delete_contact = "DELETE FROM contact WHERE `contact`.`cid` = '{$c_id}'";
    $delete_result = mysqli_query($conn,$delete_contact);
    if($delete_result){
        header("location: dashboard.php?id=".$_SESSION['id']);
    }else{
        echo 'error';
    }
}
if(isset($_GET['cid']) || isset($_GET['id'])){
    DeleteContact();
}
?>