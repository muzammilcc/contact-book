<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>
<?php 
$get_id = '';
if(isset($_GET['id'])){
    $get_id = $_SESSION['id'];
}
include 'include/config.php';
$fname = $lname = $email = $state = $zip = $datetime =  '';  
$show_id_sql = "SELECT * from `details` where `id` = '{$get_id}'";
$result_id = mysqli_query($conn,$show_id_sql);
if(mysqli_num_rows($result_id)>0){
    while($row = mysqli_fetch_assoc($result_id)){
        $fname = $row['fname'];
        $lname = $row['lname'];
        $email = $row['email'];
        $state = $row['state'];
        $zip = $row['zip'];
        $datetime = $row['datetime'];
    }
}
// update query for future update
// UPDATE `details` SET `fname` = 'muzammilc', `lname` = 'contractorc', `email` = 'mujammilcontractor98@gmail.comc', `state` = 'Gujaratc', `zip` = '396158' WHERE `details`.`id` = 11;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Welcome <?=$fname;?></title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">


    <?php
// if($_SERVER['REQUEST_METHOD']=="POST"){
// $uid = mysqli_real_escape_string($conn,$_POST['uid']);
// $ufname = mysqli_real_escape_string($conn,$_POST['ufname']);
// $ulname = mysqli_real_escape_string($conn,$_POST['ulname']);
// $uemail = mysqli_real_escape_string($conn,$_POST['uemail']);
// $ustate = mysqli_real_escape_string($conn,$_POST['ustate']);
// $uzip = mysqli_real_escape_string($conn,$_POST['uzip']);
// $update_sql = "UPDATE `details` SET `fname` = '$ufname', `lname` = '$ulname', `email` = '$uemail', `state` = '$ustate', `zip` = '$uzip' WHERE `details`.`id` = '{$uid}';";
// $result_update = mysqli_query($conn,$update_sql);
// if($result_update){
//     header('location: index.php?id='.$get_id);
// }else{
//     echo 'query failed';
// }
// }
?>
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="dashboard.php?id=<?=$get_id;?>">iMac</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" value="<?= substr($email,0,15).'....';?>" />
            </div>
        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#!">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="dashboard.php?id=<?=$get_id;?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <div class="sb-sidenav-menu-heading">Interface</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Layouts
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="layout-static.html">Static Navigation</a>
                                <a class="nav-link" href="layout-sidenav-light.html">Light Sidenav</a>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages"
                            aria-expanded="false" aria-controls="collapsePages">
                            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                            Pages
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                                    data-bs-target="#pagesCollapseAuth" aria-expanded="false"
                                    aria-controls="pagesCollapseAuth">
                                    Authentication
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                                <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne"
                                    data-bs-parent="#sidenavAccordionPages">
                                    <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" href="login.html">Login</a>
                                        <a class="nav-link" href="register.html">Register</a>
                                        <a class="nav-link" href="password.html">Forgot Password</a>
                                    </nav>
                                </div>
                                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                                    data-bs-target="#pagesCollapseError" aria-expanded="false"
                                    aria-controls="pagesCollapseError">
                                    Error
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>
                                <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne"
                                    data-bs-parent="#sidenavAccordionPages">
                                    <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link" href="401.html">401 Page</a>
                                        <a class="nav-link" href="404.html">404 Page</a>
                                        <a class="nav-link" href="500.html">500 Page</a>
                                    </nav>
                                </div>
                            </nav>
                        </div>
                        <div class="sb-sidenav-menu-heading">Addons</div>
                        <a class="nav-link" href="charts.html">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Charts
                        </a>
                        <a class="nav-link" href="tables.html">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Tables
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    <?=$fname;?> <br>Since <?= substr($datetime,0,10);?>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Dashboard</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                    <div class="row justify-content-center">
                        <div class=" col-md-6">
                            <div class="card bg-primary text-white mb-4">
                                <?php 
                            $showtotal_contact = "SELECT COUNT(uid) as `count` FROM contact where `uid` = '$get_id';";
                            $result_showtotal = mysqli_query($conn,$showtotal_contact);
                            while($row = mysqli_fetch_assoc($result_showtotal)){
                                $show_total_contact = $row['count'];
                                echo '<div class="card-body">Your Total Contacts :- '.$show_total_contact.'</div>';
                            }
                            ?>
                                <div class="card-footer d-flex align-items-center justify-content-between">

                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class=" col-md-6">
                            <div class="card bg-warning text-white mb-4">
                                <?php 
                            $showtotal_contact = "SELECT COUNT(uid) as `count` FROM notes where `uid` = '$get_id';";
                            $result_showtotal = mysqli_query($conn,$showtotal_contact);
                            while($row = mysqli_fetch_assoc($result_showtotal)){
                                $show_total_contact = $row['count'];
                                echo '<div class="card-body">Your Total Notes :- '.$show_total_contact.'</div>';
                            }
                            ?>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i style="font-size:24px" class="fa">&#xf2ba;</i>
                                    Add Your Contacts
                                </div>
                                <div class="card-body">
                                    <form method="post" action="add.php?id=<?=$get_id;?>">
                                        <div class="mb-3">
                                            <label class="form-label">Name</label>
                                            <input type="text" class="form-control" placeholder="First Name"
                                                id="exampleInputEmail1" name="cname" required
                                                aria-describedby="emailHelp">
                                            <div id="emailHelp" class="form-text"></div>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Mobile No</label>
                                            <input type="text" pattern="\d{10}" placeholder="00000-00123"
                                                class="form-control" name="cnum" required maxlength="10">
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="cbtn">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i style="font-size:24px" class="fa">&#xf24a;</i>
                                    Add Your Notes
                                </div>
                                <div class="card-body">
                                    <form method="post" action="add.php?id=<?=$get_id;?>">
                                        <div class="mb-3">
                                            <label class="form-label">Notes Title</label>
                                            <input type="text" class="form-control" name="notetitle"
                                                aria-describedby="emailHelp">
                                            <div id="emailHelp" class="form-text"></div>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Notes Description</label>
                                            <input type="text" class="form-control" placeholder="Note Description"
                                                name="notedesc">
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="nbtn">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i style="font-size:24px" class="fa">&#xf2ba;</i>
                                    Your Contacts
                                </div>
                                <div class="card-body">
                                    <table class="table" id="contactTable">
                                        <thead>
                                            <tr>
                                                <th scope="col">Sr.N0</th>
                                                <th scope="col">First</th>
                                                <th scope="col">Number</th>
                                                <th scope="col">Created</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $sr_no = 1;
                                                $table_sql = "SELECT * FROM `contact` where `uid` = '{$get_id}'";
                                                $result = $conn->query($table_sql);
                                                if(mysqli_num_rows($result)>0){
                                                    while($tb_data = mysqli_fetch_assoc($result)){
                                                        
                                            ?>
                                            <tr>
                                                <form method="post"
                                                    action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
                                                    <th><?=$sr_no;?></th>
                                                    <td><?=$tb_data['cname'];?></td>
                                                    <td><?=$tb_data['number'];?></td>
                                                    <td><?=$tb_data['datetime'];?></td>
                                                    <td class="d-flex align-items-center justify-content-center"><a
                                                            class="btn btn-danger"
                                                            href="deletecontact.php?cid=<?=$tb_data['cid'];?>?id=<?=$get_id;?>">Delete</a>
                                                    </td>
                                                </form>
                                            </tr>
                                            <?php 
                                                $sr_no++;
                                                    }
                                                }else{
                                                    echo '<div class="alert alert-danger">No Record Yet</div>';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i style="font-size:24px" class="fa">&#xf24a;</i>
                                    Your Notes
                                </div>
                                <div class="card-body">
                                    <table class="table" id="noteTable" >
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Note Title</th>
                                                <th scope="col">Note Description</th>
                                                <th scope="col">Created on</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $sr_no = 1;
                                                $table_sql_2 = "SELECT * FROM `notes` where `uid` = '{$get_id}'";
                                                $result_2 = $conn->query($table_sql_2);
                                                if(mysqli_num_rows($result_2)>0){
                                                    while($tb_data_2 = mysqli_fetch_assoc($result_2)){
                                                        
                                            ?>
                                            <tr>
                                                <th><?=$sr_no;?></th>
                                                <td><?=$tb_data_2['ntitle'];?></td>
                                                <td><?=$tb_data_2['ndesc'];?></td>
                                                <td><?=$tb_data_2['datetime'];?></td>
                                                <td class="d-flex align-items-center justify-content-center"><a
                                                        class="btn btn-danger"
                                                        href="deletecontact.php?nid=<?=$tb_data['nid'];?>?id=<?=$get_id;?>">Delete</a>
                                                </td>
                                            </tr>
                                            <?php 
                                                $sr_no++;
                                                    }
                                                }else{
                                                    echo '<div class="alert alert-danger">No Record Yet</div>';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-center small">
                        <div class="text-muted">Copyright &copy; IMac 2022</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<script src="js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
</html>